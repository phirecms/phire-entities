<?php

return [
    'entities' => [
        'index',
        'add',
        'edit',
        'remove'
    ],
    'entity-types' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];