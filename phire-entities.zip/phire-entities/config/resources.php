<?php

return [
    'entities' => [
        'index',
        'add',
        'edit',
        'export',
        'remove'
    ],
    'entity-types' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];